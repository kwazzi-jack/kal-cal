=======
Credits
=======

Main Developer
----------------

* Brian Welman <brianallisterwelman@gmail.com>

Contributors
------------

* Landman Bester <lbester@ska.ac.za>
* Jonathan Kenyon <jkenyon@ska.ac.za>
* Oleg Smirnov <oms@ska.ac.za, osmirnov@gmail.com>