# kalcal.dataset.antenna_tables attributes
from pkg_resources import resource_filename

KAT7 = resource_filename('kalcal', 
        'datasets/antenna_tables/kat-7.itrf.txt')

